﻿REST API MDG Technology
Sparx Enterprise Architect
Release Notes

Version 1.2 - 29 Jul 2019
=========================

I.   Overview

	 Provides UML-based approach to modeling REST APIs:
	 - Application Definition diagram for identifying which Path Items are implemented by which
	   Applications and their URL paths in relation to one another.
	 - Path Specification diagram for fully specifying HTTP methods and REST definitions.
	 - Schema Definition diagram for specifying schemas referenced by definitions
	 - UML Sequence diagram for representing HTTP method implementation and usage.
	
II.  System Requirements

	 - Sparx Systems Enterprise Architect v13.0 or higher (preferred).
	 - Will work with EA v12.1 and possibly earlier versions.
	 
III. Contents

	 - Readme.txt: this file
	 - REST_API_2_0_MDGTech_v1_2.xml: MDG Technology file to import into EA
	 - REST_API_2_0_Example.eapx: Example model showing usage of REST API diagram types.
	 - HTTP_Status_Codes_XMI.xml
	 - MIME_Media_Types_XMI.xml

	 The XMI files have already been imported into the example EAPX file, but provided separately for
	 loading into end-user models.
	 
IV.  Installation

	 1. Unzip SSNA_REST_API_2_0_MDGTech.zip file into a new folder.
	
	 2. Start Sparx Enterprise Architect (EA) and review the provided example model.
	 
	 3. To install the REST API 2.0 MDG Technology in one of your repositories, open that repository 
	    with EA.
	   
	 4. Select Publish -> [Technology] -> Publish -> Import MDG Technology from the EA ribbon menu.
	
	 5. In the Import MDG Technology window, select the REST_API_2_0_MDGTech_v1_2.xml file and press 
	    Import (into Model).
	   
	 6. If desired, import the HTTP Status Codes and MIME Media Types XMI files into the repository.
	    This provides a starting point for the most common status codes and media types. You can add
	    new items after importing, if desired.
	   
	    - Select the package where you wish to import in the Project Browser.
	    - Select Publish -> [Model Exchange] -> Import-XML -> Import Package From XMI
	    - In the Import Package from XML window, select the appropriate XMI file and press Import.

V.   Accessing 

	 1. Right-mouse click over a package in the browser and select Add Diagram.
	 
	 2. In the Add Diagram window, select REST API for the diagram group on the left, and select 
	    one of the diagram types:
	   
	    - Application Definition
        - Path Specification
	    - Schema Definition
		
	 3. Use the Toolbox and the Quick Linker to create new elements and relationships.

V.   Notes

     None.
		
VI.  Known Issues
		
	 None.

VII. Revision History

	 1.0 27 Jun 18: First released version.
	 1.1 11 Dec 18: Replaced "Resource" stereotype with "REST Path Item"; replaced "XML Document" 
	     stereotype with "REST Definition"; completed HTTP Method Types and Parameter properties;
		 added "REST Property" and "REST Response" stereotypes.
	 1.2 29 Jul 19: Added "combines", "references", "REST API Namespace", "REST Schema Namespace",
	     "REST Schema" stereotypes; renamed "Resource Specification" diagram type to "Path 
		 "Specification" diagram type; added "Schema Definition" diagram type.

VIII.Support

     Phone:      800.882.6051 (toll-free in US & Canada)
              +1.651.204.9282 (toll and international)
     Fax:     +1.651.204.9297
     Email:   support@sparxsystems.us
     Website: www.sparxsystems.us

VIII.Licensing
		
End of readme.txt